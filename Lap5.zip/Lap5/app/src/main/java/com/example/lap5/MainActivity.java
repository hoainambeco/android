package com.example.lap5;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    List<Product> products = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.lv);
        products.add(new Product("01","Nam",5.5,Color.RED));
        products.add(new Product("02","Mẫn",5.5,Color.BLUE));
        products.add(new Product("03","Phong",5.5,Color.GREEN));
        Adapter adapter = new Adapter(products, MainActivity.this);
        listView.setAdapter(adapter);
    }
}