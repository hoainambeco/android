package com.example.test1;

public class Android {
    public Android(String id, String ten, String ngay) {
        this.id = id;
        this.ten = ten;
        this.ngay = ngay;
    }

    public String id;
    public String ten;
    public String ngay;

    public Android() {
    }
}
