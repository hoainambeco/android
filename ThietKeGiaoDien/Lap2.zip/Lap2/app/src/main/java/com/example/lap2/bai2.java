package com.example.lap2;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class bai2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bai2);
    }
}