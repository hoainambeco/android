package com.example.asm.adapter;

public interface ItemClickListener {
    void onItemClick(int position);
}
