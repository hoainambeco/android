package com.example.test2;

public class test2 {
    public Float CanNang;
    public String date;

    public test2(Float canNang, String date) {
        this.CanNang = canNang;
        this.date = date;
    }

    public test2() {
    }
}
